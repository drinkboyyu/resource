#!/bin/bash
#actor=yumingshuai 20260610
NGINX_SBIN="/usr/local/nginx/sbin/nginx"

case "$1" in
    start)
        $NGINX_SBIN
        echo "✅ Nginx 启动成功"
        ;;
    stop)
        $NGINX_SBIN -s stop
        echo "✅ Nginx 已停止"
        ;;
    restart)
        $NGINX_SBIN -s stop
        sleep 1
        $NGINX_SBIN
        echo "✅ Nginx 重启成功"
        ;;
    status)
        ps -ef | grep nginx | grep -v grep
        ;;
    enable)
        cat > /etc/systemd/system/nginx.service <<EOF
[Unit]
Description=Nginx
After=network.target

[Service]
Type=forking
ExecStart=$NGINX_SBIN
ExecReload=$NGINX_SBIN -s reload
ExecStop=$NGINX_SBIN -s stop

[Install]
WantedBy=multi-user.target
EOF
        systemctl daemon-reload
        systemctl enable nginx
        echo "✅ 开机自启已设置"
        ;;
    *)
        echo "使用方法："
        echo "bash nginxctl.sh start    启动"
        echo "bash nginxctl.sh stop     停止"
        echo "bash nginxctl.sh restart  重启"
        echo "bash nginxctl.sh status   状态"
        echo "bash nginxctl.sh enable   开机自启"
        ;;
esac

